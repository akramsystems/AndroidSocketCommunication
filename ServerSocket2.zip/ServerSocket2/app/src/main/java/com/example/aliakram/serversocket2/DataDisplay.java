package com.example.aliakram.serversocket2;

public interface DataDisplay {
void Display(String message);
}

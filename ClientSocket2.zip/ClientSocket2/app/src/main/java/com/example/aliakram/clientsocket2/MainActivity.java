package com.example.aliakram.clientsocket2;

import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class MainActivity extends Activity {

    TextView serverMessage;
    Thread m_objThreadClient;
    Socket clientSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverMessage = (TextView) findViewById(R.id.server_message);
    }

    public void Start(View view){

        m_objThreadClient = new Thread(new Runnable() {
            @Override
            public void run() {

                try{

                    clientSocket = new Socket("192.168.45.102", 8080);

                    ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
                    oos.writeObject("Hello Server");
                    Message sMsg = Message.obtain();

                    ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
                    String strMessage = (String) ois.readObject();
                    sMsg.obj = strMessage;

                    mHandler.sendMessage(sMsg);
                    oos.close();
                    ois.close();

                }
                catch (Exception e){
                    //  TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        m_objThreadClient.start();

    }


    Handler mHandler = new Handler() {

        @Override
        public void handleMessage (Message msg){
            messageDisplay(msg.obj.toString());
        }

    };

    public void messageDisplay(String servMsg){

        serverMessage.setText(""+servMsg);

    }


}
